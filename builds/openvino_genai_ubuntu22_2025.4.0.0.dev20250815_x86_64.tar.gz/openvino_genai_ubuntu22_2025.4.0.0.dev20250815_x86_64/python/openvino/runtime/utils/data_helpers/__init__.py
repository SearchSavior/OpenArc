# -*- coding: utf-8 -*-
# Copyright (C) 2018-2025 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

from openvino.runtime.utils.data_helpers.data_dispatcher import _data_dispatch
from openvino.runtime.utils.data_helpers.wrappers import tensor_from_file
from openvino.runtime.utils.data_helpers.wrappers import _InferRequestWrapper
from openvino.runtime.utils.data_helpers.wrappers import OVDict
