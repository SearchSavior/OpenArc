# -*- coding: utf-8 -*-
# Copyright (C) 2018-2025 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

from openvino.opset14.ops import avg_pool
from openvino.opset14.ops import convert_promote_types
from openvino.opset14.ops import inverse
from openvino.opset14.ops import max_pool
