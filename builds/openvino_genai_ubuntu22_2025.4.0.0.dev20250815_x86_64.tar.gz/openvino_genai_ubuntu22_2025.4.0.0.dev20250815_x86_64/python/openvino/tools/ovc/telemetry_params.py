# Copyright (C) 2018-2025 Intel Corporation
# SPDX-License-Identifier: Apache-2.0

telemetry_params = {
    'TID': "G-W5E9RNLD4H"
}
