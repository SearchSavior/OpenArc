This package contains runtime libraries only which are required
by applications that use these libraries for the commandline flags
processing. If you want to develop such application, download
and install the development package instead.
